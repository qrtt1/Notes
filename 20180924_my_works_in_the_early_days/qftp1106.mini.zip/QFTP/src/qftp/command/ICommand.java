package qftp.command;

public interface ICommand {
    public String toString();
}
