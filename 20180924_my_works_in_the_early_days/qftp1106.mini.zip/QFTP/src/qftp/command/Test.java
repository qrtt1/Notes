package qftp.command;


public class Test implements ICommand{
    private String cmd="";
    
    public Test(String raw_cmd){
	cmd +=raw_cmd;
    }

    public String toString() {
	// TODO Auto-generated method stub
	return cmd;
    }    
    
}
