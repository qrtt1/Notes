package qftp.command.ftpService;


public class RenameFrom implements IFtpServiceCommand {
    private String cmd = "RNFR ";

    public RenameFrom(String path) {
	cmd += path;
    }

    public String toString() {
	return cmd;
    }

}
