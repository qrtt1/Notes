package qftp.command.ftpService;

public class SystemType implements IFtpServiceCommand {
	private String cmd = "SYST";

	public SystemType() {
	}

	public String toString() {
		return cmd;
	}

}
