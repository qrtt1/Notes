package qftp.command.ftpService;

public class PrintWorkingDirectory implements IFtpServiceCommand {
	private String cmd = "PWD";

	public PrintWorkingDirectory() {
	}

	public String toString() {
		return cmd;
	}

}
