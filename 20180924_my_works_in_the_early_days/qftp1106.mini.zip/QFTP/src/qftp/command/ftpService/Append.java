package qftp.command.ftpService;

public class Append implements IFtpServiceCommand{
    private String cmd="APPE ";
    
    public Append(String path){
	cmd+=path;
    }

    public String toString() {
	return cmd;
    }
    
    
}
