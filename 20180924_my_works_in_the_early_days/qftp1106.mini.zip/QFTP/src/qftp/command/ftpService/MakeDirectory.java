package qftp.command.ftpService;

public class MakeDirectory implements IFtpServiceCommand {
	private String cmd = "MKD ";

	public MakeDirectory(String path) {
		cmd += path;
	}

	public String toString() {
		return cmd;
	}

}
