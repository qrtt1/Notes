package qftp.command.ftpService;

public class Delete implements IFtpServiceCommand {
	private String cmd = "DELE ";

	public Delete(String path) {
		cmd += path;
	}

	public String toString() {
		return cmd;
	}

}
