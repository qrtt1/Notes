package qftp.command.ftpService;


public class RenameTo implements IFtpServiceCommand {
    private String cmd = "RNTO ";

    public RenameTo(String path) {
	cmd += path;
    }

    public String toString() {
	return cmd;
    }

}
