package qftp.command.ftpService;

public class NameList implements IFtpServiceCommand {
	private String cmd = "NLST ";

	public NameList() {
		cmd = "NLST";
	}

	public NameList(String path) {
		cmd += path;
	}

	public String toString() {
		return cmd;
	}

}
