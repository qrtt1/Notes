package qftp.command.ftpService;

public class Noop implements IFtpServiceCommand {
	private String cmd = "NOOP";

	public Noop() {
	}

	public String toString() {
		return cmd;
	}

}
