package qftp.command.ftpService;

public class Store implements IFtpServiceCommand{
    private String cmd="STOR ";
    
    public Store(String path){
	cmd+=path;
    }

    public String toString() {
	return cmd;
    }
    
    
}
