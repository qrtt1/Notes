package qftp.command.ftpService;

public class List implements IFtpServiceCommand {
	private String cmd = "LIST ";

	public List() {
		cmd = "LIST";
	}

	public List(String path) {
		cmd += path;
	}

	public String toString() {
		return cmd;
	}

}
