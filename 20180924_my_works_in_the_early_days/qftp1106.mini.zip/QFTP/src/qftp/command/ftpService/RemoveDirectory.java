package qftp.command.ftpService;

public class RemoveDirectory implements IFtpServiceCommand {
	private String cmd = "RMD ";

	public RemoveDirectory(String path) {
		cmd += path;
	}

	public String toString() {
		return cmd;
	}

}
