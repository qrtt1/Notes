package qftp.command.ftpService;

import qftp.command.ICommand;

public interface IFtpServiceCommand extends ICommand {
    // this is a mark interface
    // in the group, all command are used to "ftp service command"
}
