package qftp.command.ftpService;

public class Help implements IFtpServiceCommand {
	private String cmd = "HELP";

	public Help() {
	}

	public String toString() {
		return cmd;
	}

}
