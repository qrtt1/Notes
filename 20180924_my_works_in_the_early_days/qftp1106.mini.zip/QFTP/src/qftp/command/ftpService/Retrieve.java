package qftp.command.ftpService;

import qftp.misc.Encoding;

public class Retrieve implements IFtpServiceCommand{
    private String cmd="RETR ";
    
    public Retrieve(String path){
	cmd+=path;
    }

    public String toString() {
	// TODO Auto-generated method stub
	//return Encoding.b5u8(cmd);
	//return Encoding.u8(cmd);
	//return Encoding.b5(cmd);
	return cmd;
    }
    
    
}
