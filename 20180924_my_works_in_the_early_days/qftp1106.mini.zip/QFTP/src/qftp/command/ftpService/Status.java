package qftp.command.ftpService;

public class Status implements IFtpServiceCommand {
	private String cmd = "STAT ";

	public Status() {
		cmd = "STAT";
	}

	public Status(String path) {
		cmd += path;
	}

	public String toString() {
		return cmd;
	}

}
