package qftp.command.ftpService;

public class StoreUnique implements IFtpServiceCommand{
    private String cmd="STOU ";
    
    public StoreUnique(String path){
	cmd+=path;
    }

    public String toString() {
	return cmd;
    }
    
    
}
