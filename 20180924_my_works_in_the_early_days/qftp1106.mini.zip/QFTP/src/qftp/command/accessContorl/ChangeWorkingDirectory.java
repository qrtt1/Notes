package qftp.command.accessContorl;

public class ChangeWorkingDirectory implements IAccessControlCommand{
    private String cmd="CWD ";
    
    public ChangeWorkingDirectory(String path){
	cmd +=path;
    }

    public String toString() {
	// TODO Auto-generated method stub
	return cmd;
    }
    
    
}
