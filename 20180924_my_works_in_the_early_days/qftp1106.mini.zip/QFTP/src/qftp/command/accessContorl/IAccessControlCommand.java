package qftp.command.accessContorl;

import qftp.command.ICommand;

public interface IAccessControlCommand extends ICommand {
    // this is a mark interface
    // in the group, all command are used to "access control command"
}
