package qftp.command.accessContorl;

public class ChangeToParentDirectory implements IAccessControlCommand{
    private String cmd="CDUP";
    
    public ChangeToParentDirectory(){
    }

    public String toString() {
	// TODO Auto-generated method stub
	return cmd;
    }
    
    
}
