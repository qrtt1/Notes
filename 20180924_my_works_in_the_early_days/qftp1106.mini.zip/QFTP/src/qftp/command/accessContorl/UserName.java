package qftp.command.accessContorl;

public class UserName implements IAccessControlCommand {
    private String anonymous = "anonymous";

    private String cmd = "USER ";

    public UserName() {
	cmd += this.anonymous;
    }

    public UserName(String user) {
	cmd += user;
    }

    public String toString() {
	// TODO Auto-generated method stub
	return cmd;
    }

}
