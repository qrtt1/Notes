package qftp.command.accessContorl;

public class Password implements IAccessControlCommand{
    private String cmd="PASS ";
    
    public Password(String pwd){
	cmd  +=pwd;
    }

    public String toString() {
	// TODO Auto-generated method stub
	return cmd;
    }

}
