package qftp.command.accessContorl;

public class Logout implements IAccessControlCommand{
    private String cmd="QUIT";
    
    public Logout(){
    }

    public String toString() {
	// TODO Auto-generated method stub
	return cmd;
    }
    
    
}
