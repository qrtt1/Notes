package qftp.command;

public interface INonRelpyCommand {
    // mark command as non reply
}
