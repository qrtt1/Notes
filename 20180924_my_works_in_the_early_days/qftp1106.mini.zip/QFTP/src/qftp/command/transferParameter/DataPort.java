package qftp.command.transferParameter;

import qftp.command.INonRelpyCommand;

// 暫時無法測試

public class DataPort implements ITransferParameterCommand, INonRelpyCommand {
    private String cmd="PORT ";
    
    public DataPort(String port){
	cmd +=port;
    }

    public String toString() {
	// TODO Auto-generated method stub
	return cmd;
    }
    
    
}
