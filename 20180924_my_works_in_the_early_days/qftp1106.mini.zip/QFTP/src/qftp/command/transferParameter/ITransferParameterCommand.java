package qftp.command.transferParameter;

import qftp.command.ICommand;

public interface ITransferParameterCommand extends ICommand {
    // this is a mark interface
    // in the group, all command are used to "Transfer Parameter command"
}
