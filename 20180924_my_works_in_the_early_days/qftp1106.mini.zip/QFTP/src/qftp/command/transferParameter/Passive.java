package qftp.command.transferParameter;

public class Passive implements ITransferParameterCommand {
    private String cmd="PASV";
    
    public Passive(){
    }

    public String toString() {
	// TODO Auto-generated method stub
	return cmd;
    }
    
}
