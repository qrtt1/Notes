package qftp.command.transferParameter;

public class RepresentationType implements ITransferParameterCommand {
    private final static String typeASCII = "A";
    private final static String formNonPrint = "N";
    private final static String typeImage = "I";
    private String cmd = "TYPE ";

    private RepresentationType() {
    }

    public static RepresentationType getImageType() {
	RepresentationType r = new RepresentationType();
	r.cmd += typeImage;
	return r;
    }

    public static RepresentationType getASCIIWithNonPrintForm() {
	RepresentationType r = new RepresentationType();
	r.cmd += typeASCII + " " + formNonPrint;
	return r;
    }

    public String toString() {
	// TODO Auto-generated method stub
	return cmd;
    }

}
