package qftp.misc;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;
import java.util.Vector;
import java.util.regex.Pattern;

public class NetUtil {
    public static void getLocalIP() {
	Vector addrs = new Vector();
	Pattern p = Pattern
		.compile("[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}");
	try {
	    Enumeration netInterfaces = NetworkInterface.getNetworkInterfaces();
	    while (netInterfaces.hasMoreElements()) {
		NetworkInterface netInterface = (NetworkInterface) netInterfaces
			.nextElement();
		Enumeration netInterfaceAddrs = netInterface.getInetAddresses();
		while (netInterfaceAddrs.hasMoreElements()) {
		    InetAddress addr = (InetAddress) netInterfaceAddrs
			    .nextElement();
		    String theAddr = addr.getHostAddress();
		    if (p.matcher(theAddr).matches()) {
			if ("127.0.0.1".equals(theAddr)
				|| theAddr.startsWith("192.168")) {
			    continue;
			}
			//System.out.println(theAddr);
			addrs.add(theAddr);
		    }
		}
	    }
	} catch (SocketException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
    }

    public static void main(String[] args) {
	NetUtil.getLocalIP();
    }
}
