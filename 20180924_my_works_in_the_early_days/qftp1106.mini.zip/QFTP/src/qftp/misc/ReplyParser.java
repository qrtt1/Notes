package qftp.misc;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ReplyParser {
    public static int parsePassivePort(String rep) 
    throws IllegalArgumentException{
	int port = -1;
	
	Pattern p = Pattern
		.compile(".*([0-9]{1,3},[0-9]{1,3},[0-9]{1,3},[0-9]{1,3},([0-9]{1,3}),([0-9]{1,3})).*");
	Matcher m = p.matcher(rep.trim());
	if (m.matches() && m.groupCount() == 3) {
	    port = Integer.parseInt(m.group(3)) + Integer.parseInt(m.group(2))
		    * 256;
	}
	return port;
    }

    public static void main(String[] args) {
	int p = ReplyParser
		.parsePassivePort("227 Entering Passive Mode (210,59,94,134,193,34)");
	System.out.println(p);
    }
}
