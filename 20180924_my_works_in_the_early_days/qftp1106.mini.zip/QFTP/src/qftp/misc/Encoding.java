package qftp.misc;

import java.io.UnsupportedEncodingException;

public class Encoding {
    /*
    public static byte[] u8(byte[] b){
	String s = new String(b, "");
	
    }
    */
    
    public static String b5u8(String s) {
	return Encoding.changeEncoding(s, "big5", "utf-8");
    }

    public static String u8b5(String s) {
	return Encoding.changeEncoding(s, "utf-8", "big5");
    }

    public static String u8(String s) {
	return Encoding.changeEncoding(s, "utf-8");
    }

    public static String b5(String s) {
	return Encoding.changeEncoding(s, "big5");
    }

    public static String changeEncoding(String s, String target) {
	String result = null;
	try {
	    byte[] b = s.getBytes();
	    result = new String(b, target);
	} catch (UnsupportedEncodingException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
	return result;
    }

    public static String changeEncoding(String s, String source, String target) {
	String result = null;
	try {
	    byte[] b = s.getBytes(source);
	    result = new String(b, target);
	} catch (UnsupportedEncodingException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
	return result;
    }
}
