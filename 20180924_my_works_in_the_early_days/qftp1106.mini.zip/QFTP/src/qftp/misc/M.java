package qftp.misc;

public class M {
    public static void p(Object o) {
	System.out.println("\n@@@@" + o + "!!!!\n");
    }
}
