package qftp.ftpService.transfer;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Vector;

import qftp.core.IDataConnector;

public class FileThreadReceiver extends Thread {

	class Block {
		byte[] b;

		public Block(byte[] b) {
			this.setData(b);
		}

		public void setData(byte[] b) {
			this.b = b;
		}

		public byte[] getData() {
			return b;
		}
	}

	private final Vector v = new Vector();

	public int count = 10;

	public long delay = 5;

	public boolean isOk = false;
	public long fileSize = 0;

	private final IDataConnector con;

	public FileThreadReceiver(IDataConnector conn) {
		this.con = conn;
	}

	public void run() {
		byte[] b = con.get();
		if (b.length > 0) {
			this.fileSize+=b.length;
			v.add(new Block(b));
		}
		if (b.length == 0) {
			count--;
			try {
				Thread.sleep(delay);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (count > 0) {
			run();
		} else {
			this.isOk = true;
		}
	}

	public byte[] get() {
		int length = 0;
		for (int i = 0; i < v.size(); i++) {
			length += ((Block) v.get(i)).b.length;
		}
		ByteArrayOutputStream bos = new ByteArrayOutputStream(length);

		try {
			for (int i = 0; i < v.size(); i++) {
				bos.write(((Block) v.get(i)).b);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bos.toByteArray();
	}

}
