package qftp.ftpService.transfer;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import qftp.core.IDataConnector;

public class FileDeliverer {

    IDataConnector con;

    File file;

    public boolean isOk = false;

    public long delay = 1;

    public long fileTotalSize = 0;

    long fileSize = 0;

    FileInputStream fin;

    public int unitSize = 1024;

    byte[] unit = new byte[unitSize];

    public FileDeliverer(IDataConnector conn, File file) {
	this.con = conn;
	this.file = file;
	if (file.exists() && !file.isDirectory()) {
	    this.fileTotalSize = file.length();
	    try {
		fin = new FileInputStream(file);
	    } catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	    }
	}
    }

    public void run() {
	if (!file.exists() || file.isDirectory())
	    return;
	if (fin == null)
	    return;
	if (this.isOk == true)
	    return;
	while (true) {
	    try {
		if (fin.available() <= 0) {
		    this.isOk = true;
		    break;
		}
		if (fin.available() > this.unit.length) {
		    fin.read(this.unit);
		    con.put(unit);
		    this.fileSize += this.unit.length;
		} else {
		    byte[] b = new byte[1];
		    fin.read(b);
		    con.put(b);
		    this.fileSize += b.length;
		}

		Thread.sleep(this.delay);

	    } catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	    } catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	    }
	}
	
	try {
	    fin.close();
	} catch (IOException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
	con.close();
    }
}
