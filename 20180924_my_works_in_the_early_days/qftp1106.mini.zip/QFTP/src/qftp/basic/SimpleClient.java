package qftp.basic;

import java.io.File;

import qftp.basic.response.Reply;
import qftp.command.ICommand;
import qftp.command.accessContorl.ChangeToParentDirectory;
import qftp.command.accessContorl.ChangeWorkingDirectory;
import qftp.command.accessContorl.Logout;
import qftp.command.accessContorl.Password;
import qftp.command.accessContorl.UserName;
import qftp.command.ftpService.Delete;
import qftp.command.ftpService.List;
import qftp.command.ftpService.MakeDirectory;
import qftp.command.ftpService.PrintWorkingDirectory;
import qftp.command.ftpService.RemoveDirectory;
import qftp.command.ftpService.RenameFrom;
import qftp.command.ftpService.RenameTo;
import qftp.command.ftpService.Retrieve;
import qftp.command.ftpService.Store;
import qftp.command.transferParameter.Passive;
import qftp.command.transferParameter.RepresentationType;
import qftp.core.IDataConnector;
import qftp.core.ProtocolInterpreter;
import qftp.ftpService.transfer.FileDeliverer;
import qftp.ftpService.transfer.FileReceiver;

public class SimpleClient extends ProtocolInterpreter {

    public static void main(String[] args) {

	SimpleClient ftp = null;

	ftp = new SimpleClient("foo.nutn.edu.tw");
	ftp.setEncoding("utf-8", "big5");

	if (ftp.login("foo", "foopasswd")) {
	    ftp.stor(new File("/home/qrtt1/1.cpp"));
	    ftp.logout();

	}// end of login

    }

    public boolean isAutoReply = true;

    public final Reply reply = new Reply();

    public SimpleClient(String host) {
	super(host);
	reply.setRawReply(new String(super.getResponse()));
	if (this.isAutoReply)
	    this.showReply();
    }

    public SimpleClient(String host, int port) {
	super(host, port);
	reply.setRawReply(new String(super.getResponse()));
	if (this.isAutoReply)
	    this.showReply();
    }

    public boolean cdup() {
	this.executeCommand(new ChangeToParentDirectory());
	return this.checkReplyCode(250);
    }

    public boolean checkReplyCode(int code) {
	if (code == reply.getReplyCode())
	    return true;
	return false;
    }

    public boolean cwd(String path) {
	this.executeCommand(new ChangeWorkingDirectory(path));
	return this.checkReplyCode(250);
    }

    public boolean dele(String file) {
	this.executeCommand(new Delete(file));
	return this.checkReplyCode(250);
    }

    public void executeCommand(ICommand s) {
	super.executeCommand(s);
	reply.setRawReply(new String(getResponse()).trim());
	if (this.isAutoReply)
	    this.showReply();
    }

    public void executeCommandNoReply(ICommand s) {
	super.executeCommand(s);
	reply.setRawReply("");
    }

    public boolean login(String id, String passwd) {
	this.executeCommand(new UserName(id));
	if (this.checkReplyCode(331)) {
	    this.executeCommand(new Password(passwd));
	    if (this.checkReplyCode(230)) {
		// auto set type i
		this.typeI();
		return true;
	    }
	}
	return false;
    }

    public boolean loginAsAnonymous() {
	return login("anonymous", "");
    }

    public boolean logout() {
	this.executeCommand(new Logout());
	return this.checkReplyCode(221);
    }

    public boolean ls() {
	return ls(null);
    }

    public boolean ls(String path) {
	int port = pasv();
	// check pasv
	if (!this.checkReplyCode(227)) {
	    return false;
	}

	List ls = null;
	if (path == null || "".equals(path)) {
	    ls = new List();
	} else {
	    ls = new List(path);
	}
	this.executeCommand(ls);
	byte[] b = null;

	IDataConnector dcon = this.getDataConnector(port);
	FileReceiver rec = new FileReceiver(dcon);

	// check connection
	b = this.getResponse();
	this.reply.setRawReply(new String(b));

	if (this.checkReplyCode(150)) {
	    // System.out.println(new String(b) + " " + b.length);
	    this.reply.showReply();
	    rec.run();

	    b = this.getResponse();
	    this.reply.setRawReply(new String(b));
	    this.reply.showReply();

	    if (this.checkReplyCode(226)) {
		byte[] data = rec.get();
		if (data.length == 0) {
		    return false;
		} else {
		    this.reply.setReplyData(data);
		    return true;
		}
	    }
	}
	return false;
    }

    public boolean mkd(String dir) {
	this.executeCommand(new MakeDirectory(dir));
	return this.checkReplyCode(257);
    }

    public boolean move(String fr, String to) {
	this.executeCommand(new RenameFrom(fr));
	if (this.checkReplyCode(350)) {
	    this.executeCommand(new RenameTo(to));
	    return this.checkReplyCode(250);
	}
	return false;
    }

    public int pasv() {
	int port = -1;
	while (port == -1) {
	    executeCommand(new Passive());
	    try {
		Thread.sleep(300);
	    } catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	    }
	    port = this.reply.parsePassivePort();
	}
	return port;
    }

    public boolean pwd() {
	this.executeCommand(new PrintWorkingDirectory());
	return this.checkReplyCode(257);
    }

    public boolean retr(String file) {
	int port = pasv();
	// check pasv
	if (!this.checkReplyCode(227)) {
	    return false;
	}

	this.executeCommand(new Retrieve(file));
	byte[] b = null;

	IDataConnector dcon = this.getDataConnector(port);
	FileReceiver rec = new FileReceiver(dcon);

	// check connection
	b = this.getResponse();
	this.reply.setRawReply(new String(b));

	if (this.checkReplyCode(150)) {
	    // System.out.println(new String(b) + " " + b.length);
	    this.reply.showReply();
	    rec.run();

	    b = this.getResponse();
	    this.reply.setRawReply(new String(b));
	    this.reply.showReply();

	    if (this.checkReplyCode(226)) {
		byte[] data = rec.get();
		if (data.length == 0) {
		    return false;
		} else {
		    this.reply.setReplyData(data);
		    return true;
		}
	    }
	}
	return false;
    }

    public boolean rmd(String dir) {
	this.executeCommand(new RemoveDirectory(dir));
	return this.checkReplyCode(250);
    }

    public void showReply() {
	if (this.reply.getRawReply().trim().length() != 0)
	    this.reply.showReply();
    }

    public boolean stor(File file) {
	int port = pasv();
	// check pasv
	if (!this.checkReplyCode(227)) {
	    return false;
	}

	this.executeCommand(new Store(file.getName()));

	byte[] b = null;

	IDataConnector dcon = this.getDataConnector(port);
	FileDeliverer deliver = new FileDeliverer(dcon, file);

	// check connection
	b = this.getResponse();
	this.reply.setRawReply(new String(b));

	// if(false)
	if (this.checkReplyCode(150)) {
	    this.reply.showReply();
	    deliver.run();
	    try {
		Thread.sleep(200);
	    } catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	    }
	    b = this.getResponse();
	    this.reply.setRawReply(new String(b));
	    if (this.checkReplyCode(226)) {
		this.reply.showReply();
		return true;
	    }
	}
	return false;
    }

    public boolean stor(String file) {
	return stor(new File(file));
    }

    public boolean typeI() {
	this.executeCommand(RepresentationType.getImageType());
	return this.checkReplyCode(200);
    }

}
