package qftp.basic.response;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

import qftp.misc.ReplyParser;

public class Reply {
    StringBuffer rawResponse;

    public final static int No_Reply = -1;

    public class ReceivedData {
	byte[] raw;

	public void printAsString() {
	    System.out.println(new String(raw));
	}

	public void printAsString(String enc) {
	    try {
		System.out.println(new String(raw, enc));
	    } catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	    }
	}

	public boolean saveAsFile(String file) {
	    return this.saveAsFile(new File(file));
	}

	public boolean saveAsFile(File f) {
	    if (!f.exists()) {
		try {
		    f.createNewFile();
		} catch (IOException e) {
		    // TODO Auto-generated catch block
		    // e.printStackTrace();
		    return false;
		}
	    } else {
		if (!f.canWrite())
		    return false;
	    }
	    
	    try {
		FileOutputStream fout = new FileOutputStream(f);
		fout.write(this.raw);
		fout.close();
	    } catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	    } catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	    }
	    return false;
	}
    }

    public ReceivedData receivedData = null;

    public Reply() {
	this.rawResponse = new StringBuffer();
    }

    public void setReplyData(byte[] data) {
	this.receivedData = new ReceivedData();
	this.receivedData.raw = data;
    }

    public void setRawReply(String s) {
	this.rawResponse.delete(0, this.rawResponse.length());
	// this.rawResponse = new StringBuffer();
	this.rawResponse.append(s);
	// also set reply data null
	this.receivedData = null;
    }

    public boolean hasReceivedData() {
	return (this.receivedData != null);
    }

    public int getReplyCode() {
	if (this.rawResponse.length() >= 3) {
	    return Integer.parseInt(this.rawResponse.substring(0, 3));
	}
	return Reply.No_Reply;
    }

    public String getReplyString() {
	if (this.rawResponse.length() > 4) {
	    return this.rawResponse.substring(4);
	}
	return "";
    }

    public String getRawReply() {
	return this.rawResponse.toString();
    }

    public void showReply() {
	System.out.println(this.getRawReply());
    }

    public int parsePassivePort() {
	return ReplyParser.parsePassivePort(this.getRawReply());
    }

    public static void main(String[] args) {
	Reply r = new Reply();
	r.setRawReply("220 rat.nutn.edu.tw FTP server (Version 6.00LS) ready.");
	System.out.println(r.getReplyCode());
	System.out.println(r.getReplyString());
    }
}
