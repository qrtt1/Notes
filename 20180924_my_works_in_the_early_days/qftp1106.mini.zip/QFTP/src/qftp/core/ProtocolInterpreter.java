package qftp.core;

import qftp.command.ICommand;

public class ProtocolInterpreter {

	protected String host;

	protected IConnector piConn;

	private int port = 21;
	
	public void setEncoding(String serv, String cli) {
		piConn.setEncoding(serv, cli);
	}
	
	public ProtocolInterpreter(String host) {
		this(host, 21);
	}

	public ProtocolInterpreter(String host, int port) {
		this.host = host;
		piConn = new Connector(host, port);
	}

	public void executeCommand(ICommand cmd) {
		piConn.put(cmd);
		try {
			Thread.sleep(80);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void finalize() {
		piConn.close();
	}

	private IConnector getConnector() {
		return piConn;
	}

	public IDataConnector getDataConnector(long port){
		return new DataConnector(host, port);
	}

	public byte[] getResponse() {
		// if(conn==null) throw
		return piConn.get();
	}

}
