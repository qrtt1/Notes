package qftp.core;

import qftp.command.ICommand;

public interface IConnector {
    public void close();

    public byte[] get();

    public void put(String s);

    public void put(ICommand cmd);

    public void setEncoding(String server, String client);

    public boolean isSetEncoding();
}
