package qftp.core;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;

public class DataConnector implements IDataConnector {
	private InputStream _in;

	private OutputStream _out;

	private Socket s;

	public DataConnector(String host, long port) {
		try {
			s = new Socket();
			s.connect(new InetSocketAddress(host, (int) port));
			_in = s.getInputStream();

			_out = s.getOutputStream();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void close() {
		// TODO Auto-generated method stub
		try {
			_in.close();
			_out.close();
			s.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void finalize() {
		close();
	}

	public byte[] get() {
		byte[] b = null;
		try {
			int wait_count = 5;
			while (_in.available() <= 0 && wait_count-- >= 0) {
				try {
					Thread.sleep(10);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			int count = _in.available();
			b = new byte[count];
			_in.read(b);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return b;
	}

	public void put(byte[] b) {
		// TODO Auto-generated method stub
		try {
			_out.write(b);
			_out.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
