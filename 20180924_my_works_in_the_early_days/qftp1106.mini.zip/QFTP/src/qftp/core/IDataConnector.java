package qftp.core;

public interface IDataConnector {
    public void close();
    public void put(byte[] b);
    public byte[] get();
}
