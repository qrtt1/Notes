package qftp.core;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketException;

import qftp.command.ICommand;

public class Connector implements IConnector {
	private InputStream _in;

	private OutputStream _out;

	protected Socket s;

	private String[] serverAndClientEncoding;

	private boolean isSetEncoding = false;

	public Connector(String host) {
		this(host, 21);
	}

	public Connector(String host, int port) {
		try {
			s = new Socket();
			s.connect(new InetSocketAddress(host, port));
			s.setSoTimeout(100000);
			_out = s.getOutputStream();
			_in = s.getInputStream();

			while (_in.available() <= 0) {
				Thread.sleep(50);
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void close() {
		try {
			_out.flush();
			_out.close();
			_in.close();
			s.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void finalize() {
		close();
	}

	public byte[] get() {
		int size;
		int cycleCount = 10;

		byte[] b;
		try {
			while (_in.available() <= 0 && cycleCount > 0) {
				try {
					Thread.sleep(10);
					cycleCount--;
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			size = _in.available();
			b = new byte[size];
			_in.read(b);

			// Encoding.;
			if (this.isSetEncoding()) {
				String t = new String(b, this.serverAndClientEncoding[1]);
				return t.getBytes();
			}

			return b;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public void put(byte[] b) {
		try {
			_out.write(b);
			_out.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void put(ICommand cmd) {
		put(cmd.toString());
	}

	public void put(String s) {
		try {
			if (this.isSetEncoding()) {
				_out.write((s + "\r\n")
						.getBytes(this.serverAndClientEncoding[1]));
			} else {
				_out.write((s + "\r\n").getBytes());
			}
			_out.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public boolean isSetEncoding() {
		return this.isSetEncoding;
	}

	public void setEncoding(String server, String client) {
		this.isSetEncoding = true;
		this.serverAndClientEncoding = new String[] { server, client };
	}

}
